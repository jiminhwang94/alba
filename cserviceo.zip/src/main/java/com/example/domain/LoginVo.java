package com.example.domain;

import lombok.Data;

@Data
public class LoginVo 
{
	private String p_id;
	private String p_password;
	private String c_id;
	private String c_password;
}
