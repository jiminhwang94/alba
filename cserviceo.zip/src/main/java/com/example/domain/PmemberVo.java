package com.example.domain;

import lombok.Data;

@Data
public class PmemberVo {
	private String p_id;
	private String p_password;
	private String p_password_con;
	private String p_name;
	private String p_sex;
	private String p_email;
	private String p_phone;
	private String p_address;
	private String p_path;
	private String p_valid;
	private Long p_bno;
	private String rating;

}
