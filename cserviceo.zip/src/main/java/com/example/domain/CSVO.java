package com.example.domain;

import java.util.Date;

import lombok.Data;

@Data
public class CSVO {

	private Long s_num;
	private String sn_id;
	private String s_id;
	private String s_name;
	private String s_type;
	private String s_title;
	private String s_content;
	private String s_anwser;
	private Date s_datee;
}
