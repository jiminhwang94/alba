package com.example.domain;

import lombok.Data;

@Data
public class Resume {
	private String r_id;
	private String title;
	private String ability;
	private String career;
	private String hope;
	private String introduce;
	private String publicc;
	private String job;
	private String type;
	private String time;
	private String day;
}
