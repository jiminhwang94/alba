package com.example.domain;

import lombok.Data;

@Data
public class CmemberVo {
	private String c_id;
	private String c_password;
	private String c_password_con;
	private String c_email;
	private String c_phone;
	private String c_registnum;
	private String c_company;
	private String c_president;
	private String c_address;
	private String c_path;
	private String c_valid;
	private Long c_bno;
	private String rating;

}
